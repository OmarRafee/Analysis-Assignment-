package rafeeass;

public class SequenceAlignment {


    public static void main(String[] args) {
        String sequenceX = "TCCCAGTTATGTCAGGGGACACGAGCATGCAGAGAC";
        String sequenceY = "AATTGCCGCCGTCGTTTTCAGCAGTTATGTCAGATC";
        double[][] scoringMatrix = {
                {1, -0.8, -0.2, -2.3, -0.6},
                {-0.8, 1, -1.1, -0.7, -1.5},
                {-0.2, -1.1, 1, -0.5, -0.9},
                {-2.3, -0.7, -0.5, 1, -1},
                {-0.6, -1.5, -0.9, -1, 0}
        };

        String[] alignment = findAlignment(sequenceX, sequenceY, scoringMatrix);
        System.out.println("Alignment of sequenceX and sequenceY:");
        System.out.println(alignment[0]);
        System.out.println(alignment[1]);
    }

    public static String[] findAlignment(String sequenceX, String sequenceY, double[][] scoringMatrix) {
        int lengthX = sequenceX.length();
        int lengthY = sequenceY.length();

        double[][] dpMatrix = new double[lengthX + 1][lengthY + 1];

        for (int i = 0; i <= lengthX; i++) {
            dpMatrix[i][0] = i * scoringMatrix[4][4];
        }
        for (int j = 0; j <= lengthY; j++) {
            dpMatrix[0][j] = j * scoringMatrix[4][4];
        }

        for (int i = 1; i <= lengthX; i++) {
            for (int j = 1; j <= lengthY; j++) {
                double match = dpMatrix[i - 1][j - 1] + scoringMatrix[getIndex(sequenceX.charAt(i - 1))][getIndex(sequenceY.charAt(j - 1))];
                double delete = dpMatrix[i - 1][j] + scoringMatrix[getIndex(sequenceX.charAt(i - 1))][4];
                double insert = dpMatrix[i][j - 1] + scoringMatrix[4][getIndex(sequenceY.charAt(j - 1))];
                dpMatrix[i][j] = Math.max(match, Math.max(delete, insert));
            }
        }

        int i = lengthX;
        int j = lengthY;
        StringBuilder alignedSequenceX = new StringBuilder();
        StringBuilder alignedSequenceY = new StringBuilder();
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && dpMatrix[i][j] == dpMatrix[i - 1][j - 1] + scoringMatrix[getIndex(sequenceX.charAt(i - 1))][getIndex(sequenceY.charAt(j - 1))]) {
                alignedSequenceX.insert(0, sequenceX.charAt(i - 1));
                alignedSequenceY.insert(0, sequenceY.charAt(j - 1));
                i--;
                j--;
            } else if (i > 0 && dpMatrix[i][j] == dpMatrix[i - 1][j] + scoringMatrix[getIndex(sequenceX.charAt(i - 1))][4]) {
                alignedSequenceX.insert(0, sequenceX.charAt(i - 1));
                alignedSequenceY.insert(0, '-');
                i--;
            } else {
                alignedSequenceX.insert(0, '-');
                alignedSequenceY.insert(0, sequenceY.charAt(j - 1));
                j--;
            }
        }

        return new String[]{alignedSequenceX.toString(), alignedSequenceY.toString()};
    }

    public static int getIndex(char c) {
        switch (c) {
            case 'A':
                return 0;
            case 'C':
                return 1;
            case 'G':
                return 2;
            case 'T':
                return 3;
            default:
                return 4;
        }
    }
}
