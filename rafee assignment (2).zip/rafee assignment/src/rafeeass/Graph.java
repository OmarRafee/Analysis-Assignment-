package rafeeass;

import java.util.*;

class GraphA {
    Map<Integer, List<Integer>> graph;

    public GraphA() {
        this.graph = new HashMap<>();
    }

    public void addEdge(int u, int v) {
        graph.computeIfAbsent(u, k -> new ArrayList<>()).add(v);
    }

    public List<Integer> getNeighbors(int node) {
        return graph.getOrDefault(node, Collections.emptyList());
    }
}

public class Graph {
    public static List<Integer> dfs(GraphA graph, int start, boolean[] visited, List<Integer> path) {
        visited[start] = true;
        path.add(start);

        for (int neighbor : graph.getNeighbors(start)) {
            if (!visited[neighbor]) {
                dfs(graph, neighbor, visited, path);
            }
        }

        return path;
    }

    public static List<Integer> bfs(GraphA graph, int start) {
        boolean[] visited = new boolean[maxNode(graph) + 1];
        List<Integer> result = new ArrayList<>();
        Queue<Integer> queue = new LinkedList<>();

        queue.add(start);
        visited[start] = true;

        while (!queue.isEmpty()) {
            int current = queue.poll();
            result.add(current);

            for (int neighbor : graph.getNeighbors(current)) {
                if (!visited[neighbor]) {
                    queue.add(neighbor);
                    visited[neighbor] = true;
                }
            }
        }

        return result;
    }

    public static List<List<Integer>> detectCycles(GraphA graph) {
        List<List<Integer>> cycles = new ArrayList<>();

        for (int node : graph.graph.keySet()) {
            boolean[] visited = new boolean[maxNode(graph) + 1];
            List<Integer> path = new ArrayList<>();
            List<Integer> cycle = dfs(graph, node, visited, path);

            if (!cycle.isEmpty() && cycle.get(cycle.size() - 1) == cycle.get(0)) {
                cycles.add(cycle.subList(0, cycle.size() - 1));
            }
        }

        return cycles;
    }

    public static boolean isBipartite(GraphA graph, int start) {
        int[] color = new int[maxNode(graph) + 1];
        Arrays.fill(color, -1);

        color[start] = 0;
        Queue<Integer> queue = new LinkedList<>();
        queue.add(start);

        while (!queue.isEmpty()) {
            int current = queue.poll();

            for (int neighbor : graph.getNeighbors(current)) {
                if (color[neighbor] == -1) {
                    color[neighbor] = 1 - color[current];
                    queue.add(neighbor);
                } else if (color[neighbor] == color[current]) {
                    return false; // Not bipartite
                }
            }
        }

        return true; 
    }

    public static boolean isTree(GraphA graph) {
        Set<Integer> visited = new HashSet<>();

        for (int node : graph.graph.keySet()) {
            if (!visited.contains(node) && !dfsTree(graph, node, -1, visited)) {
                return false;
            }
        }

        return true;
    }

    private static boolean dfsTree(GraphA graph, int node, int parent, Set<Integer> visited) {
        if (visited.contains(node)) {
            return false;
        }

        visited.add(node);

        for (int neighbor : graph.getNeighbors(node)) {
            if (neighbor != parent && !dfsTree(graph, neighbor, node, visited)) {
                return false;
            }
        }

        return true;
    }

    private static int maxNode(GraphA graph) {
        return graph.graph.keySet().stream().mapToInt(Integer::intValue).max().orElse(0);
    }

    public static void main(String[] args) {
                GraphA graph = new GraphA();
        graph.addEdge(1, 3);
        graph.addEdge(1, 4);
        graph.addEdge(2, 1);
        graph.addEdge(2, 3);
        graph.addEdge(3, 4);
        graph.addEdge(4, 1);
        graph.addEdge(4, 2);

                List<Integer> dfsResult = dfs(graph, 1, new boolean[maxNode(graph) + 1], new ArrayList<>());
        System.out.println("DFS Result: " + dfsResult);

                List<Integer> bfsResult = bfs(graph, 1);
        System.out.println("BFS Result: " + bfsResult);

                List<List<Integer>> cycles = detectCycles(graph);
        System.out.print("With the cycles in the graph: ");
        for (List<Integer> cycle : cycles) {
            System.out.print(cycle);
            if (cycle != cycles.get(cycles.size() - 1)) {
                System.out.print(" and ");
            }
        }
        System.out.println();

                boolean isBipartiteResult = isBipartite(graph, 1);
        System.out.println("Is Bipartite: " + isBipartiteResult);

        boolean isTreeResult = isTree(graph);
        System.out.println("Is Tree: " + isTreeResult);
    }
}
